import numpy as np
import pandas as pd

data=pd.read_excel('iris .xls')

x=data.drop(['Classification'],axis=1)
y=data['Classification']


from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,random_state=42,test_size=0.2)


from sklearn.linear_model import LogisticRegression
lr=LogisticRegression()
model=lr.fit(x_train,y_train)
lr_predictions=model.predict(x_test)

from sklearn.metrics import accuracy_score

from sklearn.neighbors import KNeighborsClassifier
kmodel= KNeighborsClassifier()
kmodel.fit(x_train,y_train)
KNeighborsClassifier()

kmodel.score(x_test,y_test)


from sklearn.svm import SVC
svm_class=SVC(kernel='linear')
svm_model=svm_class.fit(x_train,y_train)
svm_predictions= svm_model.predict(x_test)


print('Logistic regression Accuracy is ', accuracy_score(y_test,lr_predictions))
print('KNN accuracy is ',kmodel.score(x_test,y_test))
print('SVM linear accuracy is ',accuracy_score(y_test,svm_predictions))


import pickle
filename='savedmodel.pkl'
pickle.dump(model,open(filename,'wb'))



load_model=pickle.load(open(filename,'rb'))